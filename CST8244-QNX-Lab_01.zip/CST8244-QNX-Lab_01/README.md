# Lab_01 - Hello World in QNX Executable project
## Setup Momentics IDE + Neutrino SDP to setup a simple project and print out "Hello World"
