#include <stdio.h>
#include <stdlib.h>

int main(void) {
	puts("Hello World from QNX Neutrino RTOS!!"); /* prints Hello World + QNX */
	puts("@author Niladri Sengupta (seng0011@algonquinlive.com)"); /* prints author details */
	puts("Excited to learn Embedded C!"); /* Author's motivation */
	return EXIT_SUCCESS;
}
