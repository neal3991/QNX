# Lab_04 – Inter-Process Communications

## Fully functional within the scope of the Lab_04
The program meets all the requirements and status of Lab_04.
The program does behave as expected. I have limit the decimal places to 2-decimal places for readability purposes.

## Known Issues
So far, the program runs smoothly and as intended. I have tested it in the scope of the lab.
I have also tested it with many decimal places. The program recognises that x/0 is an error. However 0/0=0 and it prints accordingly.
However, if one writes the command-line argument without spaces (example: 6+9), it would throw an error because the program reads that as one input/argument. 

## Expected grade
I am expecting anything in between 85% - 100%, unless I made some major mistake or forgot about scope of the important variables. I did not attempt the bonus marks for overflow (unless it was just about the scope of dividing by zero).
