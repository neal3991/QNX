# Lab_05 – Pulses - NEW

## Partially functional within the scope of the Lab_04
The function takes in the status but does not display it correctly.
It does however display the integer properly. I assume its can be fixed but I am running out of time.

## Known Issues
The status displays "status" for every status. 


## Expected grade
I am not expecting much for this Lab. I previously handed in a submission which had a bunch of really weird errors for myDevice.ca
I used simpleResMgr.c and used that file as a base and omitted and added stuff that was required and it worked.
Hopefully I pass this Lab. :(