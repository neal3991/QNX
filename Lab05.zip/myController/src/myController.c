#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/dispatch.h>
#include <sys/iofunc.h>
#include <sys/types.h>
#include <errno.h>


/* Global Variables */
#define MY_PULSE_CODE _PULSE_CODE_MINAVAIL

typedef union {
	struct _pulse pulse;
	char msg[255];
} my_message_t;

int main(int argc, char *argv[]) {
		name_attach_t *attach;
		int rcvid;
		my_message_t msg;
		char stat [128];
		char value [128];
		if ((attach = name_attach(NULL, "mydevice", 0)) == NULL) {
			return EXIT_FAILURE;
			}
		FILE *fp;
		fp = fopen("/dev/local/mydevice", "r" );
		fscanf(fp, " %s %s", stat, value);

		if(strcmp(stat, "status") == 0){
			if(strcmp(value, "closed") == 0){
			   /* Remove the name from the space */
			   name_detach(attach, 0);
			   return EXIT_SUCCESS;
			}
		fclose(fp);
		}
	while (1) {
		rcvid = MsgReceive(attach->chid, &msg, sizeof(msg), NULL);
		if (rcvid == -1) {/* Error condition, exit */
			perror ("\n Error in receiving message");
			return EXIT_FAILURE;;
		}
		if (rcvid == 0) {/* Pulse received */
			if(msg.pulse.code == MY_PULSE_CODE){
				printf("Small Integer: %d\n", msg.pulse.value.sival_int);
				fp = fopen("/dev/local/mydevice", "r" );
				fscanf(fp, "%s %s", stat, value);
				if(strcmp(stat, "status") == 0){
					printf("\nStatus: %s", stat );

				}
				if(strcmp(value, "closed") == 0){
				   /* Remove the name from the space */
				   name_detach(attach, 0);
				   return EXIT_SUCCESS;
				}
				fclose(fp);
			}
		}
		else{
			MsgReply(rcvid, EOK, 0, 0);
		}
		name_detach(attach, 0);
		return EXIT_SUCCESS;
		}
		return EXIT_SUCCESS; /* For the int main */
}
