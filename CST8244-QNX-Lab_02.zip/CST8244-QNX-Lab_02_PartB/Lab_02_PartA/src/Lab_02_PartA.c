/*
 ** sigint.c -- grabs SIGINT
 *
 * Source:  http://beej.us/guide/bgipc/html/single/bgipc.html#signals
 *          http://beej.us/guide/bgipc/examples/sigint.c
 *
 * Modified by: hurdleg@algonquincollege.com
 *
 * Usage:
 *  From Momentics IDE, run program; notice PID; enter some text, but don't hit the enter key
 *  At Neutrino prompt, issue the command: kill -s SIGINT <PID>
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>

void sigusr1_handler(int sig);

sig_atomic_t usr1Happened = 0;
sig_atomic_t signal_num = 0;

/*******************************************************************************
 * main( )
 ******************************************************************************/
int main(void) {

	/* Initialization for SIGUSR1 */
	struct sigaction usr1;
	usr1.sa_handler = sigusr1_handler; /* Setting the handler for SIGUSR1 */
	usr1.sa_flags = 0; /* or SA_RESTART */
	sigemptyset(&usr1.sa_mask); /* Initializes the signal set given by set to empty.
	 	 	 	 	 	 	 	 * With all signals excluded from the set. */
	/* End of initialization for SIGUSR1 */

	/* Print the PID once */
	printf("My PID is %d: Running...\n", getpid());
	/* Run a loop until Signal-Handler is called. */
	while(usr1Happened == 0){
		/* Checking whether sigemptyset returned 0 or -1 */
		/* sigaction() function allows the calling process to examine
		 * and/or specify the action to be associated with a specific signal. */
		if (sigaction(SIGUSR1, &usr1, NULL) == -1) {
					/* If sigemptyset returned -1 */
					perror("sigaction-sigusr1");
					exit(1);
		}
	} /* End of While-Loop */
	return 0;
} /* End of main() */

/* SIGUSR1 Interrupt Handler */
void sigusr1_handler(int sig){
	/* Setting usr1Happened to 1 to show that handler was called */
	usr1Happened = 1;
	signal_num = sig; /* Addtional information/Testing Purposes */
	/* Print out that signal has been received and exit - Print PID in each statement*/
	printf("My PID is %d: Received USR1.\n", getpid());
	printf("My PID is %d: Exiting.\n", getpid());


	/* Extras - Not a part of the lab. For testing purposes */
	/* UNCOMMENT TO SEE
	write(0, "\nSIGUSR1 Interrupt \n", 18);
	printf("\nSIGUSR1 signal: %d", signal_num);
	printf("\nusr1Happened: %d", usr1Happened);
	*/
}
