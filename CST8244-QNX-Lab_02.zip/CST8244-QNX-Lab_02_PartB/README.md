# Lab_02 - Demonstrating knowledge of Parent and Children process(es).

## Kindly ignore the Lab_02_PartA Folder within this Branch – I had forgotten that same repositories project will get pushed in the same branch even if they are separate projects.

## Fully functional within the scope of Lab_02_PartB
The program meets all the requirements and status of Lab_02_PartA. The program does behave as expected. However, if you decide to kill the parent process while the child(ren) process(es) are active, you would make Zombie processes and the Neutrino will cripple and you will not be able to run any more program on/through it. You would have to restart Neutrino to fix that issue and to continue running other QNX projects through Neutrino.

## Known Issues 
There is no runtime error. If the value entered for number of children is equal to or below zero (numChildren <=0), then the program has no child process and treats it as such and will exit the parent process and terminates the program. The intention and preamble of the program is also written in the header of the source file.

## Expected Grade
I am expecting anything in between 85% - 100%, unless some unique scope of built-in functions or variables break the program (which I doubt they will). There’s always room to learn more! 😊

