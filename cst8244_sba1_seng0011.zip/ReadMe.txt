# Assignment1 – The Electronic Puncher

## Author
Niladri Sengupta: seng0011@algonquinlive.com – ID: 040777969
## 90-95%  functional within the scope of the SBA
The program does behave as expected. This was assignment was interesting and similar to assignment 1. Knowing where to place the sleep() function was tricky. 

## Known Issues
So far, the program runs smoothly and as intended. I have tested it in the scope of the lab.
However, for test1.txt it doesn’t stop the program because it’s still in sleep but since the sleep function is implemented in the display, the controller and input are still functional. Some print statements do not work in “real-time”. They have this weird behavior where they only print when they are out of the loop and a second print statement is in process – then they both print. I am guessing that’s because of the sleep() function being implemented in the display. I think I should have implemented everything (including the sleep() function in the controller instead of the display) separately instead of trying to modularize the code – which would make the code much longer but it would at least complete what is required of it.

## Expected grade
I am expecting anything in between 80% - 90%.
