#include <stdio.h>
#include <stdlib.h>
#include <process.h>
#include <sys/neutrino.h>
#include <sys/netmgr.h>
#include <string.h>
#include <errno.h>
#include "proj.h"


int main (int argc, char* argv[]) {
	pid_t displayPid = atoi(argv[1]);
	int rcvid;
	int rpyid;// indicates who we should reply to
    int controllerCID;          // the channel ID
    int connectToDisplay;
    char msgRvs[256];
    int msgRply = 0;
    int rplyForDisplay;
    char sndMsg[256];
    int LBS = 0; /* Left Button State - 0 = Up and 1 = Down */
    int RBS = 0; /* Right Button State - 0 = Up and 1 = Down */
    /* Creating a channel for Inputs to connect */
    controllerCID = ChannelCreate (0);
    if (controllerCID == -1) {
    	perror("\nFailed to create the channel. Exiting. ");
    	exit (EXIT_FAILURE);
    }
    /* Connecting to channel created by Display */
    connectToDisplay = ConnectAttach (0, displayPid, 1, 0, 0);
	if (connectToDisplay == -1) {
		printf("\nCannot Connect to Display. Exiting ");
		return EXIT_FAILURE;
	}
	/* Printing PID of current process */
    printf("Controller startup: PID =  %d\n", getpid());
    // this is typical of a server:  it runs forever
    int actionState;
    while (1) {
        // get the message, and print it
    	actionState = -1;

        rcvid = MsgReceive (controllerCID, &msgRvs, sizeof (msgRvs), NULL);
        if(rcvid == -1){
        	printf("\nError receiving message from Inputs. Exiting. \n");
        	return EXIT_FAILURE;
        }
		/* REMOVE AND ADD IT TO CONTROLLER FOR EXIT */
        if(strcmp(msgRvs, "S") == 0) {
        	if((LBS == 0) && (RBS == 0)){
            	strcpy(sndMsg, outMessage[STOP_MSG]);
            	int exitTemp = MsgSend (connectToDisplay, &sndMsg, sizeof (sndMsg), &rplyForDisplay, sizeof (rplyForDisplay));;
            	ChannelDestroy(controllerCID);
    			exit (EXIT_SUCCESS);
        	}
        	actionState = STOP_MSG;
        	strcpy(sndMsg, "Cannot Stop/Exit program. It is not in ready state. ");
        }
        /* If event received is Left Button Down */
        if(strcmp(msgRvs, "LD") == 0) {
        	actionState = -1;
        	/* If Left Button is Up */
        	if(LBS == 0){
        		LBS = 1;

        		/* Check if both are down. If true then ARM */
        		/* NEEDS TIMER 2 seconds */
        		if((LBS == 1) && (RBS == 1)){
        			actionState = READY_MSG; /* Because in the end state transition will be "READY" */
        			/*============SENDING ARMED MESSAGE ==============*/
					printf("\nLeft and Right button are both pressed-down. Changing state please wait 2 seconds. \n");
					strcpy(sndMsg,outMessage[ARMED_MSG]);
					int tempSnd = MsgSend (connectToDisplay, &sndMsg, sizeof (sndMsg), &rplyForDisplay, sizeof (rplyForDisplay));;
					if (tempSnd == -1) {
						fprintf (stderr, "\nError during MsgSend. Exiting. \n");
						perror (NULL);
						exit (EXIT_FAILURE);
					}
					if (rplyForDisplay == -1) {
						printf("\nError receiving reply from Display\n");
					}
					/* END OF ARMED */

					/*============SENDING PUNCHED MESSAGE ==============*/
					printf("\nMachine is armed. Changing state please wait 1 second. \n");
					strcpy(sndMsg,outMessage[PUNCH_MSG]);
					int tempSnd2 = MsgSend (connectToDisplay, &sndMsg, sizeof (sndMsg), &rplyForDisplay, sizeof (rplyForDisplay));;
					if (tempSnd2 == -1) {
						fprintf (stderr, "\nError during MsgSend. Exiting. \n");
						perror (NULL);
						exit (EXIT_FAILURE);
					}
					if (rplyForDisplay == -1) {
						printf(" \nError receiving reply from Display\n");
					}
					/* END OF PUNCHED */

					/*============SENDING READY MESSAGE ==============*/
					printf("\nMachine has punched. Changing state please wait 3 seconds. \n");
					LBS = 0;
					RBS = 0;
					strcpy(sndMsg,outMessage[READY_MSG]);
        		}
        		else {
        			strcpy(sndMsg,outMessage[LEFT_DOWN_MSG]);
        			printf("\n %s ", sndMsg);
        		}
        	}

        }
        /* If event received is Right Button Down */
        if(strcmp(msgRvs, "RD") == 0) {
        	actionState = -1;
        	/* If Left Button is Up */
        	if(RBS == 0){
        		RBS = 1;
        		printf(" \n%s ", outMessage[RIGHT_DOWN_MSG]);
        		/* Check if both are down. If true then ARM */
        		if((LBS == 1) && (RBS == 1)){
					actionState = READY_MSG; /* Because in the end state transition will be "READY" */
					/*============SENDING ARMED MESSAGE ==============*/
					printf("\nLeft and Right button are both pressed-down. Changing state please wait 2 seconds. \n");
					strcpy(sndMsg,outMessage[ARMED_MSG]);
					int tempSnd = MsgSend (connectToDisplay, &sndMsg, sizeof (sndMsg), &rplyForDisplay, sizeof (rplyForDisplay));;
					if (tempSnd == -1) {
						fprintf (stderr, "\nError during MsgSend. Exiting. \n");
						perror (NULL);
						exit (EXIT_FAILURE);
					}
					if (rplyForDisplay == -1) {
						printf("\nError receiving reply from Display\n");
					}
					/* END OF ARMED */

					/*============SENDING PUNCHED MESSAGE ==============*/
					printf("\nMachine is armed. Changing state please wait 1 second. \n");
					strcpy(sndMsg,outMessage[PUNCH_MSG]);
					int tempSnd2 = MsgSend (connectToDisplay, &sndMsg, sizeof (sndMsg), &rplyForDisplay, sizeof (rplyForDisplay));;
					if (tempSnd2 == -1) {
						fprintf (stderr, "\nError during MsgSend. Exiting. \n");
						perror (NULL);
						exit (EXIT_FAILURE);
					}
					if (rplyForDisplay == -1) {
						printf("\nError receiving reply from Display\n");
					}
					/* END OF PUNCHED */

					/*============SENDING READY MESSAGE ==============*/
					printf("\nMachine has punched. Changing state please wait 3 seconds. \n");
					LBS = 0;
					RBS = 0;
					strcpy(sndMsg,outMessage[READY_MSG]);
				}
        	}

        }
        /* If event received is Left Button Up */
        if(strcmp(msgRvs, "LU") == 0) {
        	actionState = -1;
        	/* If Left Button is Down */
        	if(LBS == 1){
            	LBS = 0;
        		printf("\n%s ", outMessage[LEFT_UP_MSG]);
        		/* Check if both are down. If true then Ready */
        		if((RBS == 0)){
        			actionState = READY_MSG;
        			printf("\nLeft and Right button are both up. Changing state please wait 3 seconds. \n");
        			strcpy(sndMsg,outMessage[READY_MSG]);
        			LBS = 0;
        		}
        	}
        }

        /* If event received is Right Button Up */
        if(strcmp(msgRvs, "RU") == 0) {
        	actionState = -1;
        	/* If Right Button is Down */
        	if(LBS == 1){
        		LBS = 0;
        		printf("\n%s ", outMessage[RIGHT_UP_MSG]);
        		/* Check if both are down. If true then Ready */
        		if((LBS == 0) && (RBS == 0)){
        			actionState = READY_MSG;
					printf("\nLeft and Right button are both up. Changing state please wait 3 seconds. \n");
					strcpy(sndMsg,outMessage[READY_MSG]);        		}
        	}

        }

        /* SEND MESSAGE */
        if(actionState > -1){
        	int tempSnd = MsgSend (connectToDisplay, &sndMsg, sizeof (sndMsg), &rplyForDisplay, sizeof (rplyForDisplay));
        	if (tempSnd == -1) {
        		fprintf (stderr, "\nError during MsgSend. Exiting. \n");
        	    perror (NULL);
        	    exit (EXIT_FAILURE);
        	}
        	if (rplyForDisplay == -1) {
        		printf("\nError receiving reply from Display\n");
        	}
        }
        /* Reply back to Input for Event Input again */
        rpyid = MsgReply(rcvid, 1, &msgRply, sizeof(msgRply));
        if(rpyid == -1){
        	printf("\nError replying to Inputs. Exiting. \n");
            return EXIT_FAILURE;
        }

	}
    // destroy the channel when done
    ChannelDestroy(controllerCID);
    return EXIT_SUCCESS;
}
