#include <stdio.h>
#include <stdlib.h>
#include <process.h>
#include <sys/neutrino.h>
#include <sys/netmgr.h>
#include <string.h>
#include <errno.h>

#include "proj.h"
int main(int argc, char *argv[]) {
	pid_t controllerPid = atoi(argv[1]);
	char inputEvent[10];

	char sendMsg [128];
	int rmsg;
	int cidToController = ConnectAttach (0, controllerPid, 1, 0, 0);
	if (cidToController == -1) {
			printf("Cannot Connect to Server. Please try again\n");
			return EXIT_FAILURE;
		}
	while (1) {
			/* Display all the options - INPUT EVENT */
			printf("\nEnter the input (LD, LU, RD, RU, S):\n");
			if(scanf(" %s", inputEvent) == -1){
				printf("\nError on scanning Input-Event. \n");
				return 0;
			}
			/* REMOVE AND ADD IT TO CONTROLLER FOR EXIT */
			if(strcmp(inputEvent, "S") == 0) {
				printf("Exiting Controller.\n");
				printf("Exiting Display.\n");
				strcpy(sendMsg, "S");
				int exitTemp = MsgSend (cidToController, &sendMsg, sizeof (sendMsg), &rmsg, sizeof (rmsg));
    			exit (EXIT_SUCCESS);
			}

			/* Send event to Controller */
			if (MsgSend (cidToController, &inputEvent, sizeof (inputEvent)+ 1, &rmsg, sizeof (rmsg)) == -1) {
					fprintf (stderr, "Error during MsgSend\n");
					perror (NULL);
					exit (EXIT_FAILURE);
				}
			if (rmsg == -1) {
				printf("\nError receiving reply from Controller - Input-Event");
			}
	}
	ConnectDetach(cidToController);
	return EXIT_SUCCESS;
}
