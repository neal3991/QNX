#include <stdio.h>
#include <stdlib.h>
#include <process.h>
#include <sys/neutrino.h>
#include <sys/netmgr.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include "proj.h"

int main (int argc, char* argv[]) {

	char msg [200];
	int displayCID;
	int rplyMsg = 0;
	printf("Display startup: PID = %d\n", getpid());
	//pid_t serverpid = atoi(argv[1]);
	displayCID = ChannelCreate(0);

	/* Continuous while loop for receiving message from controller
	 * and displaying output messages*/
	while (1) {
		int rcid = MsgReceive(displayCID, &msg, sizeof(msg), NULL);
		if (rcid == -1) {
			printf("\nError receiving message from Controller \n");
			return EXIT_FAILURE;
		}
		/* Display the message first */
		printf("%s \n", msg);

		/* Different wait times depending on the message */
		if(strcmp(msg, outMessage[READY_MSG]) == 0){
			sleep(3);
		}
		if(strcmp(msg, outMessage[ARMED_MSG]) == 0){
			sleep(2);
		}
		if(strcmp(msg, outMessage[PUNCH_MSG]) == 0){
			sleep(1);
		}
		if(strcmp(msg, outMessage[STOP_MSG]) == 0){
			sleep(5);
			exit (EXIT_SUCCESS);
		}
		int rpid = MsgReply(rcid, 1, &rplyMsg, sizeof(rplyMsg));
		if (rpid == -1) {
			printf("\nError replying to Controller \n");
			return EXIT_FAILURE;
		}
	}
	/* Destroy the channel when done */
	 ChannelDestroy(displayCID);
   return EXIT_SUCCESS;
}
