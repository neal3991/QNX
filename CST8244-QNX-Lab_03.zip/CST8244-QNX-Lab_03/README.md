# Lab_03 - Threads in Semaphores

## Fully functional within the scope of the Lab_03
The program meets all the requirements and status of Lab_03.
The program does behave as expected. 

## Known Issues
So far, the program runs smoothly and as intended. I have tested it in the scope of the lab.
However, if from all the threads are already unblocked and more sem_post is sent, it still tries to unblock the threads (which are already unblocked).

## Expected grade
I am expecting anything in between 85% - 100%, unless I made some major mistake or forgot about scope of the important variables or if I lose marks because of the sem_post signal being sent to the unblocked threads.
